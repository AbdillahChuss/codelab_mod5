<?php

 namespace app\Config;

 class DatabaseConfig{
    public $host = "localhost";
    public $user = "root";
    public $pass = "";
    public $database_name = "order";
    public $port = 3306;
 }